

<?php
require_once __DIR__ . "/includes/auth.php";
require_once __DIR__ . "/config/db.php";

// Escape output safely
function escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Page settings
$pageTitle = "Campus Event Hub | Discover Events";
$assetPrefix = "";

// Get search and category filters
$search = trim((string) ($_GET['search'] ?? ''));
$selectedCategory = trim((string) ($_GET['category'] ?? ''));

// Get available categories
$categorySql = "SELECT DISTINCT category
                FROM events
                WHERE status = 'open'
                AND event_date >= CURDATE()
                ORDER BY category ASC";

$categoryStmt = $pdo->query($categorySql);
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);

// Build event query
$sql = "SELECT
            id,
            title,
            description,
            category,
            event_date,
            start_time,
            end_time,
            venue,
            capacity
        FROM events
        WHERE status = 'open'
        AND event_date >= CURDATE()";

$params = [];

// Search events
if ($search !== '') {

    $sql .= " AND (
                title LIKE :title_search
                OR description LIKE :description_search
              )";

    $params['title_search'] = '%' . $search . '%';
    $params['description_search'] = '%' . $search . '%';
}

// Category filter
if ($selectedCategory !== '') {

    $sql .= " AND category = :category";

    $params['category'] = $selectedCategory;
}

// Sort events
$sql .= " ORDER BY event_date ASC, start_time ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

$eventCount = count($events);

// Load shared header
require __DIR__ . "/includes/header.php";
?>

<!-- =====================================
     HERO SECTION
===================================== -->

<section class="home-hero">

    <div class="container">

        <div class="hero-content">

            <span class="hero-label">
                MINI CAMPUS EVENT HUB
            </span>

            <h1>
                Discover Events.<br>
                <span>Connect. Learn. Experience.</span>
            </h1>

            <p>
                Explore exciting campus activities, workshops,
                seminars, and student events.
                Find your next campus experience today!
            </p>

            <a href="#upcoming-events" class="btn hero-btn">
                Explore Events &darr;
            </a>

        </div>

        <div class="hero-decoration">
            <div class="hero-circle circle-one"></div>
            <div class="hero-circle circle-two"></div>
        </div>

    </div>

</section>

<main class="container py-5">

    <!-- =====================================
         PAGE INTRODUCTION
    ====================================== -->

    <section id="upcoming-events" class="mb-4">

        <div class="section-intro">

            <div>
                <span class="section-label">
                    WHAT'S HAPPENING
                </span>

                <h2 class="section-title">
                    Upcoming Events
                </h2>

                <p class="text-secondary mb-0">
                    Find activities and opportunities happening on campus.
                </p>
            </div>

            <div class="event-count-card">

                <span class="count-number">
                    <?php echo $eventCount; ?>
                </span>

                <span class="count-label">
                    Events Found
                </span>

            </div>

        </div>

    </section>

    <!-- =====================================
         SEARCH AND FILTER
    ====================================== -->

    <section class="search-section mb-5">

        <form method="GET" action="index.php">

            <div class="row g-3 align-items-end">

                <!-- Search input -->

                <div class="col-md-5">

                    <label for="search" class="form-label">
                        Search Events
                    </label>

                    <input
                        type="search"
                        class="form-control"
                        id="search"
                        name="search"
                        placeholder="Search event title or keyword..."
                        value="<?php echo escape($search); ?>"
                    >

                </div>

                <!-- Category filter -->

                <div class="col-md-4">

                    <label for="category" class="form-label">
                        Event Category
                    </label>

                    <select
                        class="form-select"
                        id="category"
                        name="category"
                    >

                        <option value="">
                            All Categories
                        </option>

                        <?php foreach ($categories as $category): ?>

                            <option
                                value="<?php echo escape($category['category']); ?>"
                                <?php
                                echo $selectedCategory === $category['category']
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php echo escape($category['category']); ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <!-- Search buttons -->

                <div class="col-md-3">

                    <div class="d-flex gap-2">

                        <button
                            type="submit"
                            class="btn btn-primary flex-grow-1"
                        >
                            Search
                        </button>

                        <a
                            href="index.php"
                            class="btn btn-outline-secondary"
                        >
                            Reset
                        </a>

                    </div>

                </div>

            </div>

        </form>

    </section>

    <!-- =====================================
         EVENT RESULTS
    ====================================== -->

    <section>

        <div class="d-flex justify-content-between
                    align-items-center flex-wrap gap-2 mb-4">

            <div>

                <h3 class="results-heading">
                    Explore Campus Events
                </h3>

                <p class="text-secondary mb-0">
                    Browse the latest upcoming activities.
                </p>

            </div>

            <span class="results-badge">
                <?php echo $eventCount; ?>
                Available
            </span>

        </div>

        <?php if ($eventCount > 0): ?>

            <div class="row g-4">

                <?php foreach ($events as $event): ?>

                    <div class="col-md-6 col-lg-4">

                        <div class="card event-card h-100">

                            <!-- Card accent -->

                            <div class="event-card-accent"></div>

                            <div class="card-body d-flex flex-column">

                                <!-- Category -->

                                <div class="mb-3">

                                    <span class="event-category-badge">
                                        <?php echo escape($event['category']); ?>
                                    </span>

                                </div>

                                <!-- Event title -->

                                <h4 class="event-card-title">
                                    <?php echo escape($event['title']); ?>
                                </h4>

                                <!-- Description -->

                                <p class="event-card-description">
                                    <?php
                                    echo escape($event['description']);
                                    ?>
                                </p>

                                <!-- Event details -->

                                <div class="event-card-information">

                                    <div class="event-detail-row">

                                        <span class="event-detail-icon">
                                            &#128197;
                                        </span>

                                        <div>
                                            <small>Event Date</small>

                                            <strong>
                                                <?php
                                                echo date(
                                                    "F j, Y",
                                                    strtotime($event['event_date'])
                                                );
                                                ?>
                                            </strong>
                                        </div>

                                    </div>

                                    <div class="event-detail-row">

                                        <span class="event-detail-icon">
                                            &#128336;
                                        </span>

                                        <div>
                                            <small>Event Time</small>

                                            <strong>
                                                <?php
                                                echo date(
                                                    "g:i A",
                                                    strtotime($event['start_time'])
                                                );
                                                ?>

                                                -

                                                <?php
                                                echo date(
                                                    "g:i A",
                                                    strtotime($event['end_time'])
                                                );
                                                ?>
                                            </strong>
                                        </div>

                                    </div>

                                    <div class="event-detail-row">

                                        <span class="event-detail-icon">
                                            &#128205;
                                        </span>

                                        <div>
                                            <small>Venue</small>

                                            <strong>
                                                <?php echo escape($event['venue']); ?>
                                            </strong>
                                        </div>

                                    </div>

                                    <div class="event-detail-row">

                                        <span class="event-detail-icon">
                                            &#128101;
                                        </span>

                                        <div>
                                            <small>Capacity</small>

                                            <strong>
                                                <?php echo (int) $event['capacity']; ?>
                                                Participants
                                            </strong>
                                        </div>

                                    </div>

                                </div>

                                <!-- View details -->

                                <div class="mt-auto pt-4">

                                    <a
                                        href="event-details.php?id=<?php echo (int) $event['id']; ?>"
                                        class="btn btn-primary w-100 event-view-btn"
                                    >
                                        View Event Details
                                        &rarr;
                                    </a>

                                </div>

                            </div>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <!-- No events found -->

            <div class="empty-events">

                <div class="empty-events-icon">
                    &#128269;
                </div>

                <h3>No Events Found</h3>

                <p>
                    Sorry, there are no upcoming events matching
                    your search or selected category.
                </p>

                <a href="index.php" class="btn btn-primary">
                    View All Events
                </a>

            </div>

        <?php endif; ?>

    </section>

</main>

<?php
require __DIR__ . "/includes/footer.php";
?>
