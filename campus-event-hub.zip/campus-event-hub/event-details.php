
<?php
require_once __DIR__ . "/includes/auth.php";
require_once __DIR__ . "/config/db.php";

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Escape output
function escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Validate event ID
$eventId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$eventId || $eventId < 1) {
    http_response_code(404);
    $event = null;
} else {

    // Fetch event information
    $sql = "SELECT
                e.id,
                e.title,
                e.description,
                e.category,
                e.event_date,
                e.start_time,
                e.end_time,
                e.venue,
                e.capacity,
                e.status,
                (
                    SELECT COUNT(*)
                    FROM registrations r
                    WHERE r.event_id = e.id
                    AND r.status = 'Registered'
                ) AS registered_count
            FROM events e
            WHERE e.id = :id
            AND e.status <> 'archived'
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $eventId]);

    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        http_response_code(404);
    }
}

// Registration calculations
$registeredCount = $event ? (int) $event['registered_count'] : 0;
$capacity = $event ? (int) $event['capacity'] : 0;

$remainingSlots = max(0, $capacity - $registeredCount);

$isFull = $event && $remainingSlots === 0;

$isOpen = $event
    && $event['status'] === 'open'
    && !$isFull
    && $event['event_date'] >= date('Y-m-d');

$registrationPercentage = $capacity > 0
    ? min(100, ($registeredCount / $capacity) * 100)
    : 0;

// Page title
$pageTitle = $event
    ? $event['title'] . ' | Event Details'
    : 'Event Not Found';

$assetPrefix = "";

require __DIR__ . "/includes/header.php";
?>

<main class="container py-5">

    <?php if (!$event): ?>

        <!-- EVENT NOT FOUND -->

        <div class="event-not-found text-center shadow-sm">

            <div class="not-found-icon">!</div>

            <h2>Event Not Found</h2>

            <p>
                Sorry! This event does not exist
                or is no longer available.
            </p>

            <a href="index.php" class="btn btn-primary">
                &larr; Back to Events
            </a>

        </div>

    <?php else: ?>

        <!-- BACK BUTTON -->

        <a href="index.php" class="back-link">
            &larr; Back to Events
        </a>

        <div class="row g-4 mt-2">

            <!-- LEFT: EVENT DETAILS -->

            <div class="col-lg-8">

                <div class="card event-detail-card shadow-sm">

                    <!-- EVENT HEADER -->

                    <div class="event-detail-header">

                        <span class="event-category">
                            <?php echo escape($event['category']); ?>
                        </span>

                        <h1>
                            <?php echo escape($event['title']); ?>
                        </h1>

                        <p>
                            Discover the details and join
                            this exciting campus event.
                        </p>

                    </div>

                    <div class="card-body p-4 p-md-5">

                        <!-- DESCRIPTION -->

                        <div class="event-section">

                            <h2 class="section-heading">
                                About This Event
                            </h2>

                            <p class="event-description">
                                <?php
                                echo nl2br(escape($event['description']));
                                ?>
                            </p>

                        </div>

                        <hr class="section-divider">

                        <!-- EVENT INFORMATION -->

                        <h2 class="section-heading mb-4">
                            Event Information
                        </h2>

                        <div class="row g-3">

                            <div class="col-md-6">

                                <div class="event-info-box">

                                    <div class="info-icon">
                                        &#128197;
                                    </div>

                                    <div>
                                        <small>Event Date</small>

                                        <strong>
                                            <?php
                                            echo date(
                                                "F j, Y",
                                                strtotime($event['event_date'])
                                            );
                                            ?>
                                        </strong>
                                    </div>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="event-info-box">

                                    <div class="info-icon">
                                        &#128336;
                                    </div>

                                    <div>
                                        <small>Event Time</small>

                                        <strong>
                                            <?php
                                            echo date(
                                                "g:i A",
                                                strtotime($event['start_time'])
                                            );
                                            ?>
                                            -
                                            <?php
                                            echo date(
                                                "g:i A",
                                                strtotime($event['end_time'])
                                            );
                                            ?>
                                        </strong>
                                    </div>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="event-info-box">

                                    <div class="info-icon">
                                        &#128205;
                                    </div>

                                    <div>
                                        <small>Event Venue</small>

                                        <strong>
                                            <?php echo escape($event['venue']); ?>
                                        </strong>
                                    </div>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="event-info-box">

                                    <div class="info-icon">
                                        &#128101;
                                    </div>

                                    <div>
                                        <small>Event Capacity</small>

                                        <strong>
                                            <?php echo $capacity; ?> Participants
                                        </strong>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <hr class="section-divider">

                        <!-- REGISTRATION STATUS -->

                        <div class="registration-overview">

                            <div class="d-flex justify-content-between
                                        align-items-center flex-wrap gap-2">

                                <h2 class="section-heading mb-0">
                                    Registration Overview
                                </h2>

                                <?php if ($isOpen): ?>

                                    <span class="badge bg-success">
                                        Registration Open
                                    </span>

                                <?php elseif ($isFull): ?>

                                    <span class="badge bg-danger">
                                        Fully Booked
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-secondary">
                                        <?php
                                        echo $event['event_date'] < date('Y-m-d')
                                            ? 'Ended'
                                            : escape(ucfirst($event['status']));
                                        ?>
                                    </span>

                                <?php endif; ?>

                            </div>

                            <div class="d-flex justify-content-between
                                        mt-4 mb-2">

                                <span class="text-secondary">
                                    Registered Participants
                                </span>

                                <strong>
                                    <?php echo $registeredCount; ?>
                                    / <?php echo $capacity; ?>
                                </strong>

                            </div>

                            <div class="progress event-progress">

                                <div
                                    class="progress-bar bg-success"
                                    role="progressbar"
                                    style="width: <?php echo $registrationPercentage; ?>%"
                                    aria-valuenow="<?php echo round($registrationPercentage); ?>"
                                    aria-valuemin="0"
                                    aria-valuemax="100"
                                ></div>

                            </div>

                            <div class="d-flex justify-content-between
                                        mt-2 flex-wrap gap-2">

                                <small>
                                    <?php echo $registeredCount; ?>
                                    registered
                                </small>

                                <small class="text-success fw-bold">
                                    <?php echo $remainingSlots; ?>
                                    remaining slots
                                </small>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <!-- RIGHT: REGISTRATION CARD -->

            <div class="col-lg-4">

                <div class="card registration-card shadow-sm">

                    <div class="card-header registration-card-header">

                        <h3 class="mb-1">
                            Join This Event
                        </h3>

                        <p class="mb-0">
                            Be part of this exciting experience!
                        </p>

                    </div>

                    <div class="card-body p-4">

                        <?php if ($isOpen): ?>

                            <div class="registration-highlight">

                                <div class="registration-check">
                                    &#10003;
                                </div>

                                <div>
                                    <strong>Slots Available!</strong>

                                    <small>
                                        Secure your place today.
                                    </small>
                                </div>

                            </div>

                            <?php if (!empty($_SESSION['user_id'])): ?>

                                <p class="text-secondary mb-4">
                                    Ready to participate?
                                    Click the button below to register.
                                </p>

                                <form
                                    method="POST"
                                    action="register-event.php"
                                >

                                    <input
                                        type="hidden"
                                        name="event_id"
                                        value="<?php echo (int) $event['id']; ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?php echo escape($_SESSION['csrf_token']); ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="btn btn-primary w-100"
                                    >
                                        Register for This Event
                                    </button>

                                </form>

                                <a
                                    href="my-registrations.php"
                                    class="btn btn-outline-primary w-100 mt-3"
                                >
                                    My Registrations
                                </a>

                            <?php else: ?>

                                <p class="text-secondary mb-4">
                                    Please log in or create a student
                                    account to register for this event.
                                </p>

                                <a
                                    href="register.php"
                                    class="btn btn-primary w-100 mb-3"
                                >
                                    Create Student Account
                                </a>

                                <a
                                    href="login.php"
                                    class="btn btn-outline-primary w-100"
                                >
                                    Login to Register
                                </a>

                            <?php endif; ?>

                        <?php else: ?>

                            <div class="registration-unavailable">

                                <div class="unavailable-icon">
                                    &#9432;
                                </div>

                                <h5>Registration Unavailable</h5>

                                <p>
                                    Registration is currently unavailable
                                    for this event.
                                </p>

                                <a
                                    href="index.php"
                                    class="btn btn-outline-primary w-100"
                                >
                                    Browse Other Events
                                </a>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

                <!-- ADDITIONAL INFORMATION -->

                <div class="card shadow-sm mt-4">

                    <div class="card-body p-4">

                        <h5 class="fw-bold mb-3">
                            Why Join This Event?
                        </h5>

                        <ul class="event-benefits">

                            <li>
                                Discover new experiences.
                            </li>

                            <li>
                                Connect with fellow students.
                            </li>

                            <li>
                                Learn and develop new skills.
                            </li>

                            <li>
                                Create unforgettable memories.
                            </li>

                        </ul>

                    </div>

                </div>

            </div>

        </div>

    <?php endif; ?>

</main>

<?php require __DIR__ . "/includes/footer.php"; ?>
