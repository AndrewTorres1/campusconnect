
<?php

require_once __DIR__ . "/config/db.php";

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM events");
    $eventCount = $stmt->fetchColumn();

    echo "<h1>Database connection successful!</h1>";
    echo "<p>Database: campus_event_hub</p>";
    echo "<p>Sample events found: " . (int) $eventCount . "</p>";
} catch (PDOException $e) {
    error_log("Database test error: " . $e->getMessage());
    echo "<h1>Database query failed.</h1>";
}
