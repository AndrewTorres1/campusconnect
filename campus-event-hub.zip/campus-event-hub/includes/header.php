
<?php
if (!function_exists('escape')) {
    function escape($value) {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}

$isAdminPage = $isAdminPage ?? false;
$assetPrefix = $assetPrefix ?? "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>
        <?= isset($pageTitle)
            ? escape($pageTitle) . " | Mini Campus Event Hub"
            : "Mini Campus Event Hub" ?>
    </title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet"
    >

    <!-- Custom CSS -->
    <link
        rel="stylesheet"
        href="<?= escape($assetPrefix) ?>assets/css/style.css"
    >

    <script
        src="<?= escape($assetPrefix) ?>assets/js/script.js"
        defer
    ></script>

    <style>
        :root {
            --dark-green: #14532d;
            --primary-green: #15803d;
            --bright-green: #16a34a;
            --light-green: #dcfce7;
        }

        /* NAVBAR */
        .main-navbar {
            background: linear-gradient(
                110deg,
                var(--dark-green),
                var(--primary-green)
            );
            padding: 13px 0;
            box-shadow: 0 3px 12px rgba(20, 83, 45, 0.18);
        }

        /* BRAND */
        .navbar-brand {
            color: #ffffff !important;
            font-size: 21px;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .navbar-brand i {
            color: #86efac;
            margin-right: 8px;
        }

        /* NAV LINKS */
        .main-navbar .nav-link {
            color: #ecfdf5 !important;
            font-weight: 600;
            margin: 0 5px;
            transition: 0.2s ease;
        }

        .main-navbar .nav-link:hover {
            color: #86efac !important;
        }

        /* ADMIN BUTTON */
        .admin-nav-button {
            color: #ffffff !important;
            border: 1px solid rgba(255,255,255,0.55);
            border-radius: 8px;
            padding: 8px 14px !important;
            transition: 0.2s ease;
        }

        .admin-nav-button:hover {
            background: #ffffff;
            color: var(--primary-green) !important;
        }

        /* LOGIN BUTTON */
        .login-nav-button {
            color: #ffffff !important;
            border: 1px solid rgba(255,255,255,0.55);
            border-radius: 8px;
            padding: 8px 17px !important;
        }

        .login-nav-button:hover {
            background: #ffffff;
            color: var(--primary-green) !important;
        }

        /* SIGN UP BUTTON */
        .signup-nav-button {
            background: #060606;
            color: var(--dark-green) !important;
            border-radius: 8px;
            padding: 8px 17px !important;
            font-weight: 700;
            transition: 0.2s ease;
        }

        .signup-nav-button:hover {
            background: var(--light-green);
            color: var(--dark-green) !important;
        }

        /* USER GREETING */
        .navbar-user {
            color: #dcfce7;
            font-weight: 600;
            margin-right: 12px;
        }

        /* LOGOUT BUTTON */
        .logout-button {
            background: #ffffff;
            color: var(--dark-green);
            border: none;
            border-radius: 8px;
            padding: 8px 15px;
            font-weight: 700;
            transition: 0.2s ease;
        }

        .logout-button:hover {
            background: var(--light-green);
            color: var(--dark-green);
        }

        /* MOBILE TOGGLER */
        .main-navbar .navbar-toggler {
            border-color: rgba(255,255,255,0.5);
        }

        .main-navbar .navbar-toggler:focus {
            box-shadow: 0 0 0 3px rgba(134, 239, 172, 0.3);
        }

        .main-navbar .navbar-toggler-icon {
            filter: brightness(0) invert(1);
        }

        @media (max-width: 991px) {
            .main-navbar .navbar-nav {
                padding-top: 12px;
            }

            .main-navbar .nav-link {
                margin: 5px 0;
            }

            .navbar-user {
                display: block;
                margin: 12px 0;
            }
        }
    </style>
</head>

<body>

<!-- MAIN NAVIGATION -->
<nav class="navbar navbar-expand-lg navbar-dark main-navbar">
    <div class="container">

        <!-- BRAND -->
        <a class="navbar-brand" href="<?= escape($assetPrefix) ?>index.php">
            <i class="bi bi-mortarboard-fill"></i>
            Mini Campus Event Hub
        </a>

        <!-- MOBILE MENU BUTTON -->
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNavbar"
            aria-controls="mainNavbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- NAVIGATION CONTENT -->
        <div class="collapse navbar-collapse" id="mainNavbar">

            <ul class="navbar-nav ms-auto align-items-lg-center">

                <!-- HOME -->
                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="<?= escape($assetPrefix) ?>index.php"
                    >
                        <i class="bi bi-house-door me-1"></i>
                        Home
                    </a>
                </li>

                <?php if (
                    isset($_SESSION['user_id']) &&
                    ($_SESSION['role'] ?? '') === 'admin' &&
                    !$isAdminPage
                ): ?>
                    <li class="nav-item">
                        <a
                            class="nav-link admin-nav-button"
                            href="<?= escape($assetPrefix) ?>admin/dashboard.php"
                        >
                            <i class="bi bi-speedometer2 me-1"></i>
                            Admin Dashboard
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (isset($_SESSION['user_id'])): ?>

                    <!-- LOGGED-IN USER -->
                    <li class="nav-item">
                        <span class="navbar-user">
                            <i class="bi bi-person-circle me-1"></i>
                            <?= escape($_SESSION['full_name'] ?? 'User') ?>
                        </span>
                    </li>

                    <!-- LOGOUT -->
                    <li class="nav-item">
                        <form
                            method="POST"
                            action="<?= escape($assetPrefix) ?>logout.php"
                            class="d-inline"
                        >
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= escape($_SESSION['csrf_token'] ?? '') ?>"
                            >

                            <button type="submit" class="logout-button">
                                <i class="bi bi-box-arrow-right me-1"></i>
                                Logout
                            </button>
                        </form>
                    </li>

                <?php else: ?>

                    <!-- LOGIN -->
                    <li class="nav-item">
                        <a
                            class="nav-link login-nav-button"
                            href="<?= escape($assetPrefix) ?>login.php"
                        >
                            Login
                        </a>
                    </li>

                    <!-- SIGN UP -->
                    <li class="nav-item">
                        <a
                            class="nav-link signup-nav-button"
                            href="<?= escape($assetPrefix) ?>register.php"
                        >
                            Sign Up
                        </a>
                    </li>

                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
