
<footer class="main-footer text-white text-center py-4">
    <div class="container">

        <div class="mb-2">
            <i class="bi bi-mortarboard-fill me-2"></i>
            <strong>Mini Campus Event Hub</strong>
        </div>

        <small class="footer-text">
            &copy; <?php echo date('Y'); ?>
            Mini Campus Event Hub. All rights reserved.
        </small>

    </div>
</footer>

<style>
    .main-footer {
        background: linear-gradient(
            110deg,
            #14532d,
            #15803d
        );
        border-top: 3px solid #16a34a;
    }

    .main-footer strong {
        color: #ffffff;
        font-size: 15px;
    }

    .footer-text {
        color: #dcfce7;
        font-size: 13px;
    }
</style>

<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
