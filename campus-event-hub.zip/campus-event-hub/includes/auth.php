
<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * Require a logged-in user.
 */
function require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header("Location: /campus-event-hub/login.php");
        exit;
    }
}

/**
 * Require a specific account role.
 */
function require_role(string $role): void
{
    require_login();

    if (($_SESSION['role'] ?? '') !== $role) {
        http_response_code(403);
        exit("You do not have permission to access this page.");
    }
}
