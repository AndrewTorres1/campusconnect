
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/config/db.php";

$pageTitle = "Student Registration";
$assetPrefix = "";

// Escape output safely
if (!function_exists('escape')) {
    function escape($value) {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];
$success = false;

$fullName = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $fullName = trim($_POST["full_name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";
    $csrfToken = $_POST["csrf_token"] ?? "";

    // CSRF validation
    if (
        empty($csrfToken) ||
        !hash_equals($_SESSION['csrf_token'], $csrfToken)
    ) {
        $errors[] = "Invalid request. Please refresh the page and try again.";
    }

    // Full name validation
    if ($fullName === "") {
        $errors[] = "Full name is required.";
    } elseif (strlen($fullName) > 100) {
        $errors[] = "Full name must not exceed 100 characters.";
    }

    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    } elseif (strlen($email) > 150) {
        $errors[] = "Email must not exceed 150 characters.";
    }

    // Password validation
    if (strlen($password) < 8) {
        $errors[] = "Password must contain at least 8 characters.";
    } elseif (strlen($password) > 4096) {
        $errors[] = "Password is too long.";
    }

    // Confirm password
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // Check duplicate email and register account
    if (empty($errors)) {
        try {
            $checkEmail = $pdo->prepare(
                "SELECT id FROM users WHERE email = ? LIMIT 1"
            );
            $checkEmail->execute([$email]);

            if ($checkEmail->fetch()) {
                $errors[] = "This email address is already registered.";
            } else {
                $hashedPassword = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $insertUser = $pdo->prepare(
                    "INSERT INTO users (full_name, email, password, role)
                     VALUES (?, ?, ?, 'student')"
                );

                $insertUser->execute([
                    $fullName,
                    $email,
                    $hashedPassword
                ]);

                $success = true;

                $fullName = "";
                $email = "";

                // Generate a new CSRF token
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }

        } catch (PDOException $e) {

            if ($e->getCode() === '23000') {
                $errors[] = "This email address is already registered.";
            } else {
                error_log($e->getMessage());
                $errors[] = "Something went wrong. Please try again later.";
            }
        }
    }
}

require __DIR__ . "/includes/header.php";
?>

<style>
/* PAGE BACKGROUND */
.registration-page {
    min-height: 85vh;
    padding: 45px 15px;
    background: #f0fdf4;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* MAIN CONTAINER */
.registration-container {
    width: 100%;
    max-width: 1050px;
    background: #ffffff;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 12px 35px rgba(20, 83, 45, 0.12);
}

/* LEFT PANEL */
.registration-intro {
    background: linear-gradient(
        145deg,
        #14532d,
        #15803d,
        #16a34a
    );
    color: #ffffff;
    padding: 55px 40px;
    min-height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.registration-intro .brand-icon {
    width: 65px;
    height: 65px;
    border-radius: 16px;
    background: rgba(255, 255, 255, 0.18);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    margin-bottom: 25px;
}

.registration-intro h2 {
    font-size: 30px;
    font-weight: 800;
    margin-bottom: 15px;
}

.registration-intro p {
    color: #dcfce7;
    line-height: 1.7;
}

.registration-features {
    margin-top: 25px;
    padding: 0;
    list-style: none;
}

.registration-features li {
    margin-bottom: 14px;
    color: #ecfdf5;
}

.registration-features i {
    margin-right: 10px;
}

/* RIGHT PANEL */
.registration-form-panel {
    padding: 45px 50px;
}

.registration-form-panel h3 {
    color: #14532d;
    font-weight: 800;
    margin-bottom: 8px;
}

.registration-subtitle {
    color: #64748b;
    margin-bottom: 28px;
}

/* FORM LABELS */
.form-label {
    color: #14532d;
    font-weight: 600;
    margin-bottom: 8px;
}

/* INPUT FIELDS */
.registration-form .form-control {
    min-height: 48px;
    border: 1px solid #d1d5db;
    border-radius: 9px;
    padding: 10px 14px;
}

.registration-form .form-control:focus {
    border-color: #16a34a;
    box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.13);
}

/* PASSWORD FIELD */
.password-wrapper {
    position: relative;
}

.password-wrapper .form-control {
    padding-right: 48px;
}

.toggle-password {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: transparent;
    color: #15803d;
    cursor: pointer;
}

/* REGISTER BUTTON */
.register-button {
    width: 100%;
    min-height: 49px;
    border: none;
    border-radius: 9px;
    background: #15803d;
    color: #ffffff;
    font-weight: 700;
    font-size: 16px;
    transition: 0.2s ease;
}

.register-button:hover {
    background: #14532d;
    transform: translateY(-1px);
}

/* LOGIN LINK */
.login-link {
    color: #15803d;
    font-weight: 700;
    text-decoration: none;
}

.login-link:hover {
    color: #14532d;
    text-decoration: underline;
}

/* ALERTS */
.registration-alert {
    border-radius: 9px;
    font-size: 14px;
}

/* RESPONSIVE DESIGN */
@media (max-width: 767px) {
    .registration-page {
        padding: 20px 12px;
    }

    .registration-intro {
        padding: 35px 25px;
    }

    .registration-intro h2 {
        font-size: 25px;
    }

    .registration-form-panel {
        padding: 35px 25px;
    }
}
</style>

<div class="registration-page">
    <div class="registration-container">

        <div class="row g-0">

            <!-- LEFT INTRODUCTION PANEL -->
            <div class="col-md-5">
                <div class="registration-intro">

                    <div class="brand-icon">
                        <i class="bi bi-mortarboard-fill"></i>
                    </div>

                    <h2>Join Our Campus Community!</h2>

                    <p>
                        Create your student account and stay updated
                        with the latest campus events and activities.
                    </p>

                    <ul class="registration-features">
                        <li>
                            <i class="bi bi-calendar-event"></i>
                            Discover campus events
                        </li>

                        <li>
                            <i class="bi bi-pencil-square"></i>
                            Register for activities
                        </li>

                        <li>
                            <i class="bi bi-bell"></i>
                            Stay updated with announcements
                        </li>
                    </ul>

                </div>
            </div>

            <!-- RIGHT REGISTRATION FORM -->
            <div class="col-md-7">
                <div class="registration-form-panel">

                    <h3>Create Student Account</h3>

                    <p class="registration-subtitle">
                        Fill in the information below to get started.
                    </p>

                    <?php if ($success): ?>
                        <div class="alert alert-success registration-alert">
                            <i class="bi bi-check-circle-fill me-2"></i>
                            Registration successful! You can now
                            <a href="login.php" class="login-link">
                                log in
                            </a>.
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger registration-alert">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= escape($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" class="registration-form">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= escape($_SESSION['csrf_token']) ?>"
                        >

                        <!-- FULL NAME -->
                        <div class="mb-3">
                            <label class="form-label">
                                Full Name
                            </label>

                            <input
                                type="text"
                                name="full_name"
                                class="form-control"
                                placeholder="Enter your full name"
                                maxlength="100"
                                value="<?= escape($fullName) ?>"
                                required
                            >
                        </div>

                        <!-- EMAIL -->
                        <div class="mb-3">
                            <label class="form-label">
                                Email Address
                            </label>

                            <input
                                type="email"
                                name="email"
                                class="form-control"
                                placeholder="Enter your email address"
                                maxlength="150"
                                value="<?= escape($email) ?>"
                                required
                            >
                        </div>

                        <!-- PASSWORD -->
                        <div class="mb-3">
                            <label class="form-label">
                                Password
                            </label>

                            <div class="password-wrapper">
                                <input
                                    type="password"
                                    name="password"
                                    class="form-control"
                                    placeholder="Create a password"
                                    minlength="8"
                                    required
                                >

                                <button
                                    type="button"
                                    class="toggle-password"
                                    aria-label="Show password"
                                >
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>

                            <small class="text-muted">
                                Password must be at least 8 characters.
                            </small>
                        </div>

                        <!-- CONFIRM PASSWORD -->
                        <div class="mb-4">
                            <label class="form-label">
                                Confirm Password
                            </label>

                            <div class="password-wrapper">
                                <input
                                    type="password"
                                    name="confirm_password"
                                    class="form-control"
                                    placeholder="Confirm your password"
                                    required
                                >

                                <button
                                    type="button"
                                    class="toggle-password"
                                    aria-label="Show password"
                                >
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                        </div>

                        <!-- SUBMIT BUTTON -->
                        <button type="submit" class="register-button">
                            Create Account
                            <i class="bi bi-arrow-right ms-2"></i>
                        </button>

                        <p class="text-center mt-4 mb-0">
                            Already have an account?
                            <a href="login.php" class="login-link">
                                Log in here
                            </a>
                        </p>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<script>
document.querySelectorAll('.toggle-password').forEach(button => {
    button.addEventListener('click', function () {

        const input = this.parentElement.querySelector('input');
        const icon = this.querySelector('i');

        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
            this.setAttribute('aria-label', 'Hide password');
        } else {
            input.type = 'password';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
            this.setAttribute('aria-label', 'Show password');
        }
    });
});
</script>

<?php require __DIR__ . "/includes/footer.php"; ?>
