
<?php
require_once __DIR__ . "/includes/auth.php";
require_once __DIR__ . "/config/db.php";

require_login();

$pageTitle = "My Registrations";
$assetPrefix = "";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$message = "";
$messageType = "success";

// Handle registration cancellation before displaying the header.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    $registrationId = filter_input(
        INPUT_POST,
        'registration_id',
        FILTER_VALIDATE_INT
    );

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        $message = "Invalid form submission. Refresh the page and try again.";
        $messageType = "danger";
    } elseif (!$registrationId || $registrationId < 1) {
        $message = "Invalid registration.";
        $messageType = "danger";
    } else {
        try {
            // Only the registration owner can cancel before the event date.
            $stmt = $pdo->prepare(
                "UPDATE registrations r
                 INNER JOIN events e ON e.id = r.event_id
                 SET r.status = 'cancelled'
                 WHERE r.id = :registration_id
                   AND r.user_id = :user_id
                   AND r.status = 'registered'
                   AND e.event_date >= CURDATE()"
            );

            $stmt->execute([
                'registration_id' => $registrationId,
                'user_id' => (int) $_SESSION['user_id']
            ]);

            if ($stmt->rowCount() > 0) {
                $message = "Your event registration has been cancelled.";
            } else {
                $message = "This registration could not be cancelled. It may already be cancelled, belong to another account, or be for an event that has already passed.";
                $messageType = "warning";
            }
        } catch (PDOException $e) {
            error_log("Cancel registration error: " . $e->getMessage());
            $message = "We could not cancel your registration. Please try again.";
            $messageType = "danger";
        }
    }
}

// Load this student's registrations.
$stmt = $pdo->prepare(
    "SELECT
        r.id AS registration_id,
        r.status AS registration_status,
        r.registered_at,
        e.id AS event_id,
        e.title,
        e.description,
        e.category,
        e.event_date,
        e.start_time,
        e.end_time,
        e.venue,
        e.status AS event_status
     FROM registrations r
     INNER JOIN events e ON e.id = r.event_id
     WHERE r.user_id = :user_id
     ORDER BY r.registered_at DESC"
);

$stmt->execute([
    'user_id' => (int) $_SESSION['user_id']
]);

$registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include the shared page header only after processing is complete.
require __DIR__ . "/includes/header.php";
?>

<main class="container py-5">
    <div class="mb-4">
        <h1 class="fw-bold">My Registrations</h1>
        <p class="text-secondary">
            View your event registrations and manage upcoming events.
        </p>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?php echo escape($messageType); ?>">
            <?php echo escape($message); ?>
        </div>
    <?php endif; ?>

    <?php if (count($registrations) > 0): ?>
        <div class="row g-4">
            <?php foreach ($registrations as $registration): ?>
                <?php
                $isRegistered = strtolower(
                    (string) $registration['registration_status']
                ) === 'registered';

                $canCancel = $isRegistered
                    && $registration['event_date'] >= date('Y-m-d');
                ?>

                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body d-flex flex-column">
                            <span class="badge text-bg-info align-self-start mb-3">
                                <?php echo escape($registration['category']); ?>
                            </span>

                            <h5 class="card-title fw-bold">
                                <?php echo escape($registration['title']); ?>
                            </h5>

                            <p class="text-secondary">
                                <?php echo escape($registration['description']); ?>
                            </p>

                            <ul class="list-unstyled small">
                                <li class="mb-2">
                                    <strong>Date:</strong>
                                    <?php
                                    echo date(
                                        'F j, Y',
                                        strtotime($registration['event_date'])
                                    );
                                    ?>
                                </li>

                                <li class="mb-2">
                                    <strong>Time:</strong>
                                    <?php
                                    echo date(
                                        'g:i A',
                                        strtotime($registration['start_time'])
                                    );
                                    ?>
                                    –
                                    <?php
                                    echo date(
                                        'g:i A',
                                        strtotime($registration['end_time'])
                                    );
                                    ?>
                                </li>

                                <li class="mb-2">
                                    <strong>Venue:</strong>
                                    <?php echo escape($registration['venue']); ?>
                                </li>

                                <li>
                                    <strong>Registration:</strong>

                                    <?php if ($isRegistered): ?>
                                        <span class="badge text-bg-success">
                                            Registered
                                        </span>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">
                                            Cancelled
                                        </span>
                                    <?php endif; ?>
                                </li>
                            </ul>

                            <div class="mt-auto pt-3 d-grid gap-2">
                                <a
                                    href="event-details.php?id=<?php echo (int) $registration['event_id']; ?>"
                                    class="btn btn-outline-primary"
                                >
                                    View Event
                                </a>

                                <?php if ($canCancel): ?>
                                    <form
                                        method="POST"
                                        action="my-registrations.php"
                                        onsubmit="return confirm('Are you sure you want to cancel this registration?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?php echo escape($_SESSION['csrf_token']); ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="registration_id"
                                            value="<?php echo (int) $registration['registration_id']; ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-outline-danger w-100"
                                        >
                                            Cancel Registration
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            You have not registered for any events yet.
            <a href="index.php" class="alert-link">
                Browse upcoming events
            </a>.
        </div>
    <?php endif; ?>
</main>

<?php require __DIR__ . "/includes/footer.php"; ?>
