
<?php
require_once __DIR__ . "/includes/auth.php";
require_once __DIR__ . "/config/db.php";

require_login();

function escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = "";
$messageType = "danger";
$eventId = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    $message = "Please open an event and use its Register button.";
} else {
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        $message = "Invalid form submission. Return to the event page and try again.";
    } elseif (!$eventId || $eventId < 1) {
        $message = "Invalid event. Please select a valid event.";
    } else {
        try {
            $pdo->beginTransaction();

            // Lock the event row so simultaneous registrations check capacity safely.
            $stmt = $pdo->prepare(
                "SELECT id, title, event_date, capacity, status
                 FROM events
                 WHERE id = :id
                 FOR UPDATE"
            );
            $stmt->execute(['id' => $eventId]);
            $event = $stmt->fetch();

            if (!$event) {
                $pdo->rollBack();
                $message = "This event could not be found.";
            } elseif (
                $event['status'] !== 'open' ||
                $event['event_date'] < date('Y-m-d')
            ) {
                $pdo->rollBack();
                $message = "This event is closed or is no longer available for registration.";
            } else {
                // Check whether this student already has a registration.
                $stmt = $pdo->prepare(
                    "SELECT id, status
                     FROM registrations
                     WHERE user_id = :user_id AND event_id = :event_id
                     LIMIT 1"
                );
                $stmt->execute([
                    'user_id' => (int) $_SESSION['user_id'],
                    'event_id' => $eventId
                ]);
                $existing = $stmt->fetch();

                if ($existing && $existing['status'] === 'registered') {
                    $pdo->rollBack();
                    $message = "You are already registered for this event.";
                } else {
                    // Count only active registrations.
                    $stmt = $pdo->prepare(
                        "SELECT COUNT(*)
                         FROM registrations
                         WHERE event_id = :event_id
                           AND status = 'registered'"
                    );
                    $stmt->execute(['event_id' => $eventId]);
                    $registeredCount = (int) $stmt->fetchColumn();

                    if ($registeredCount >= (int) $event['capacity']) {
                        $pdo->rollBack();
                        $message = "Sorry, this event is already full.";
                    } else {
                        if ($existing) {
                            // Restore a previously cancelled registration.
                            $stmt = $pdo->prepare(
                                "UPDATE registrations
                                 SET status = 'registered',
                                     registered_at = CURRENT_TIMESTAMP
                                 WHERE id = :id"
                            );
                            $stmt->execute(['id' => $existing['id']]);
                        } else {
                            $stmt = $pdo->prepare(
                                "INSERT INTO registrations
                                    (user_id, event_id, status)
                                 VALUES
                                    (:user_id, :event_id, 'registered')"
                            );
                            $stmt->execute([
                                'user_id' => (int) $_SESSION['user_id'],
                                'event_id' => $eventId
                            ]);
                        }

                        $pdo->commit();
                        $messageType = "success";
                        $message = "You have successfully registered for " .
                                   $event['title'] . "!";
                    }
                }
            }
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log("Event registration error: " . $e->getMessage());
            $message = "Registration could not be completed. Please try again.";
        }
    }
}
require __DIR__ . "/includes/header.php";?>


<body class="bg-light">


<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <div class="alert alert-<?php echo escape($messageType); ?>">
                        <?php echo escape($message); ?>
                    </div>

                    <div class="d-grid gap-2">
                        <a href="my-registrations.php" class="btn btn-primary">
                            View My Registrations
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary">
                            Back to Events
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php require __DIR__ . "/includes/footer.php"; ?>
</body>
</html>
