

<?php
require_once __DIR__ . "/../includes/auth.php";
require_once __DIR__ . "/../config/db.php";

require_role('admin');

$pageTitle = "Admin Dashboard";
$assetPrefix = "../";

function escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$totalEvents = (int) $pdo->query(
    "SELECT COUNT(*) FROM events"
)->fetchColumn();

$openEvents = (int) $pdo->query(
    "SELECT COUNT(*) FROM events WHERE status = 'open'"
)->fetchColumn();

$totalStudents = (int) $pdo->query(
    "SELECT COUNT(*) FROM users WHERE role = 'student'"
)->fetchColumn();

$totalRegistrations = (int) $pdo->query(
    "SELECT COUNT(*) FROM registrations WHERE status = 'registered'"
)->fetchColumn();

$sql = "SELECT
            e.id,
            e.title,
            e.event_date,
            e.status,
            e.capacity,
            (
                SELECT COUNT(*)
                FROM registrations r
                WHERE r.event_id = e.id
                  AND r.status = 'registered'
            ) AS registered_count
        FROM events e
        ORDER BY e.created_at DESC
        LIMIT 10";

$events = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

$isAdminPage = true;

require __DIR__ . "/../includes/header.php";
?>

<style>
    :root {
        --dark-gray: #374151;
        --primary-gray: #4b5563;
        --medium-gray: #6b7280;
        --light-gray: #e5e7eb;
        --pale-gray: #f3f4f6;
    }

    body {
        background: #f3f4f6;
        color: #374151;
    }

    .dashboard-wrapper {
        padding-top: 35px;
        padding-bottom: 50px;
    }

    .dashboard-title {
        font-size: 28px;
        font-weight: 750;
        color: #1f2937;
    }

    .dashboard-subtitle {
        color: #6b7280;
        font-size: 14px;
    }

    .stat-card {
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 15px;
        padding: 23px;
        height: 100%;
        transition: .2s ease;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(0,0,0,.06);
    }

    .stat-icon {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        font-size: 21px;
        margin-bottom: 18px;
    }

    .icon-blue,
    .icon-green,
    .icon-purple,
    .icon-orange {
        background: #e5e7eb;
        color: #4b5563;
    }

    .stat-label {
        font-size: 13px;
        color: #6b7280;
        margin-bottom: 7px;
    }

    .stat-number {
        font-size: 29px;
        font-weight: 750;
        color: #1f2937;
        margin: 0;
    }

    .dashboard-panel {
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 15px;
        overflow: hidden;
    }

    .panel-header {
        padding: 21px 24px;
        border-bottom: 1px solid #e5e7eb;
    }

    .panel-title {
        font-size: 17px;
        font-weight: 700;
        margin: 0;
        color: #1f2937;
    }

    .quick-action {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 17px;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        text-decoration: none;
        color: #374151;
        transition: .2s ease;
        height: 100%;
    }

    .quick-action:hover {
        background: #f3f4f6;
        border-color: #9ca3af;
        color: #1f2937;
        transform: translateY(-2px);
    }

    .action-icon {
        width: 43px;
        height: 43px;
        border-radius: 11px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #e5e7eb;
        color: #4b5563;
        font-size: 19px;
        flex-shrink: 0;
    }

    .action-title {
        font-weight: 650;
        font-size: 14px;
        margin-bottom: 3px;
    }

    .action-description {
        color: #8792a5;
        font-size: 12px;
        margin: 0;
    }

    .event-table {
        margin: 0;
    }

    .event-table thead th {
        background: #f3f4f6;
        color: #6b7280;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: .6px;
        font-weight: 700;
        padding: 15px 18px;
        border-bottom: 1px solid #e5e7eb;
        white-space: nowrap;
    }

    .event-table tbody td {
        padding: 17px 18px;
        font-size: 13px;
        border-color: #f3f4f6;
        vertical-align: middle;
    }

    .event-name {
        font-weight: 650;
        color: #374151;
    }

    .status-badge {
        display: inline-block;
        padding: 6px 11px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .status-open {
        background: #e5e7eb;
        color: #374151;
    }

    .status-closed {
        background: #f3f4f6;
        color: #6b7280;
    }

    .status-other {
        background: #e5e7eb;
        color: #4b5563;
    }

    .capacity-bar {
        width: 90px;
        height: 6px;
        background: #e5e7eb;
        border-radius: 10px;
        overflow: hidden;
        margin-top: 6px;
    }

    .capacity-progress {
        height: 100%;
        background: #6b7280;
        border-radius: 10px;
    }

    .btn-action {
        font-size: 12px;
        font-weight: 600;
        border-radius: 7px;
        padding: 6px 11px;
    }

    .primary-button {
        background: #4b5563;
        border: none;
        color: white;
        padding: 10px 17px;
        border-radius: 9px;
        font-size: 13px;
        font-weight: 600;
        text-decoration: none;
        transition: .2s ease;
    }

    .primary-button:hover {
        background: #1f2937;
        color: white;
    }

    @media(max-width: 576px) {
        .dashboard-title {
            font-size: 23px;
        }

        .stat-card {
            padding: 17px;
        }

        .stat-number {
            font-size: 25px;
        }

        .panel-header {
            padding: 17px;
        }
    }
</style>

<main class="container dashboard-wrapper">

    <!-- HEADER -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>
            <p class="text-secondary fw-semibold small mb-1">
                ADMINISTRATION
            </p>

            <h1 class="dashboard-title mb-1">
                Dashboard Overview
            </h1>

            <p class="dashboard-subtitle mb-0">
                Welcome to your campus event management dashboard.
            </p>
        </div>

        <a href="add-event.php" class="primary-button">
            + Create New Event
        </a>

    </div>

    <!-- STATISTICS -->
    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon icon-blue">📅</div>
                <p class="stat-label">Total Events</p>
                <h2 class="stat-number">
                    <?php echo $totalEvents; ?>
                </h2>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon icon-green">✓</div>
                <p class="stat-label">Open Events</p>
                <h2 class="stat-number">
                    <?php echo $openEvents; ?>
                </h2>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon icon-purple">♙</div>
                <p class="stat-label">Student Accounts</p>
                <h2 class="stat-number">
                    <?php echo $totalStudents; ?>
                </h2>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <div class="stat-icon icon-orange">☷</div>
                <p class="stat-label">Active Registrations</p>
                <h2 class="stat-number">
                    <?php echo $totalRegistrations; ?>
                </h2>
            </div>
        </div>

    </div>

    <!-- QUICK ACTIONS -->
    <div class="dashboard-panel mb-4">

        <div class="panel-header">
            <h2 class="panel-title">Quick Actions</h2>
            <p class="dashboard-subtitle mb-0 mt-1">
                Manage your campus events efficiently.
            </p>
        </div>

        <div class="p-3 p-md-4">
            <div class="row g-3">

                <div class="col-md-4">
                    <a href="add-event.php" class="quick-action">
                        <div class="action-icon">＋</div>
                        <div>
                            <div class="action-title">Add New Event</div>
                            <p class="action-description">
                                Create and publish an event.
                            </p>
                        </div>
                    </a>
                </div>

                <div class="col-md-4">
                    <a href="registrations.php" class="quick-action">
                        <div class="action-icon">☷</div>
                        <div>
                            <div class="action-title">Registrations</div>
                            <p class="action-description">
                                View student registrations.
                            </p>
                        </div>
                    </a>
                </div>

                <div class="col-md-4">
                    <a href="../index.php" class="quick-action">
                        <div class="action-icon">↗</div>
                        <div>
                            <div class="action-title">Public Events</div>
                            <p class="action-description">
                                View the public event page.
                            </p>
                        </div>
                    </a>
                </div>

            </div>
        </div>

    </div>

    <!-- RECENT EVENTS -->
    <div class="dashboard-panel">

        <div class="panel-header d-flex justify-content-between align-items-center flex-wrap gap-2">

            <div>
                <h2 class="panel-title">Recent Events</h2>
                <p class="dashboard-subtitle mb-0 mt-1">
                    Overview of your latest 10 events.
                </p>
            </div>

            <span class="badge text-bg-light border text-secondary">
                <?php echo count($events); ?> Events
            </span>

        </div>

        <div class="table-responsive">

            <table class="table event-table">

                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Event Date</th>
                        <th>Status</th>
                        <th>Registrations</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (empty($events)): ?>

                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="fs-2 mb-2">📭</div>
                            <h6 class="fw-bold">No Events Found</h6>
                            <p class="text-secondary small mb-0">
                                Create your first campus event to get started.
                            </p>
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($events as $event): ?>

                        <?php
                        $status = strtolower((string) $event['status']);

                        $statusClass = 'status-other';

                        if ($status === 'open') {
                            $statusClass = 'status-open';
                        } elseif ($status === 'closed') {
                            $statusClass = 'status-closed';
                        }

                        $registered = (int) $event['registered_count'];
                        $capacity = (int) $event['capacity'];

                        $percentage = $capacity > 0
                            ? min(100, ($registered / $capacity) * 100)
                            : 0;
                        ?>

                        <tr>

                            <td>
                                <div class="event-name">
                                    <?php echo escape($event['title']); ?>
                                </div>
                            </td>

                            <td>
                                <?php
                                echo date(
                                    "M j, Y",
                                    strtotime($event['event_date'])
                                );
                                ?>
                            </td>

                            <td>
                                <span class="status-badge <?php echo $statusClass; ?>">
                                    <?php echo escape(ucfirst($status)); ?>
                                </span>
                            </td>

                            <td>
                                <div class="fw-semibold">
                                    <?php echo $registered; ?>
                                    <span class="text-secondary fw-normal">
                                        / <?php echo $capacity; ?>
                                    </span>
                                </div>

                                <div class="capacity-bar">
                                    <div
                                        class="capacity-progress"
                                        style="width: <?php echo $percentage; ?>%;"
                                    ></div>
                                </div>
                            </td>

                            <td>
                                <div class="d-flex gap-1">

                                    <a
                                        href="edit-event.php?id=<?php echo (int) $event['id']; ?>"
                                        class="btn btn-warning btn-action"
                                    >
                                        Edit
                                    </a>

                                    <form
                                        action="delete-event.php"
                                        method="POST"
                                        class="d-inline"
                                        onsubmit="return confirm('Are you sure you want to delete this event?');"
                                    >

                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?php echo escape($_SESSION['csrf_token'] ?? ''); ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="event_id"
                                            value="<?php echo (int) $event['id']; ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-danger btn-action"
                                        >
                                            Delete
                                        </button>

                                    </form>

                                </div>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</main>

<?php require __DIR__ . "/../includes/footer.php"; ?>
