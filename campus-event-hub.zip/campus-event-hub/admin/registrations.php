
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';

require_role('admin');

// Create CSRF token.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$messageType = '';

// Handle cancel, restore, or delete registration.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        $message = 'Invalid form submission. Please try again.';
        $messageType = 'danger';

    } else {

        $registrationId = filter_var(
            $_POST['registration_id'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        $action = $_POST['action'] ?? '';

        if (
            $registrationId === false ||
            !in_array($action, ['cancel', 'restore', 'delete'], true)
        ) {
            $message = 'Invalid registration information.';
            $messageType = 'danger';

        } else {

            try {

                if ($action === 'delete') {

                    // Permanently delete only the registration record.
                    $delete = $pdo->prepare(
                        'DELETE FROM registrations WHERE id = ?'
                    );

                    $delete->execute([$registrationId]);

                    if ($delete->rowCount() > 0) {
                        $message = 'Registration deleted permanently.';
                        $messageType = 'success';
                    } else {
                        $message = 'Registration not found.';
                        $messageType = 'danger';
                    }

                } else {

                    $newStatus = $action === 'cancel'
                        ? 'Cancelled'
                        : 'Registered';

                    $update = $pdo->prepare(
                        'UPDATE registrations
                         SET status = :status
                         WHERE id = :id'
                    );

                    $update->execute([
                        'status' => $newStatus,
                        'id' => $registrationId
                    ]);

                    if ($update->rowCount() > 0) {

                        $message = $newStatus === 'Cancelled'
                            ? 'Registration cancelled successfully.'
                            : 'Registration restored successfully.';

                        $messageType = 'success';

                    } else {

                        $check = $pdo->prepare(
                            'SELECT status
                             FROM registrations
                             WHERE id = ?'
                        );

                        $check->execute([$registrationId]);
                        $currentStatus = $check->fetchColumn();

                        if ($currentStatus === false) {
                            $message = 'Registration not found.';
                            $messageType = 'danger';

                        } elseif ($currentStatus === $newStatus) {
                            $message = 'The registration already has that status.';
                            $messageType = 'info';

                        } else {
                            $message = 'Could not update the registration.';
                            $messageType = 'danger';
                        }
                    }
                }

            } catch (PDOException $e) {
                error_log($e->getMessage());
                $message = 'The operation failed. Please try again.';
                $messageType = 'danger';
            }
        }
    }
}

// Search and filter.
$search = trim((string) ($_GET['search'] ?? ''));
$statusFilter = (string) ($_GET['status'] ?? '');

$allowedStatuses = ['Registered', 'Cancelled'];

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

// Retrieve registrations.
$sql = "
    SELECT
        r.id AS registration_id,
        r.status AS registration_status,
        r.registered_at,
        u.full_name,
        u.email,
        e.title AS event_title,
        e.event_date
    FROM registrations r
    INNER JOIN users u ON r.user_id = u.id
    INNER JOIN events e ON r.event_id = e.id
    WHERE 1 = 1
";

$params = [];

if ($search !== '') {

    $sql .= "
        AND (
            u.full_name LIKE :student_search
            OR u.email LIKE :email_search
            OR e.title LIKE :event_search
        )
    ";

    $searchTerm = '%' . $search . '%';

    $params['student_search'] = $searchTerm;
    $params['email_search'] = $searchTerm;
    $params['event_search'] = $searchTerm;
}

if ($statusFilter !== '') {
    $sql .= ' AND r.status = :status_filter';
    $params['status_filter'] = $statusFilter;
}

$sql .= ' ORDER BY r.registered_at DESC, r.id DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Summary counts.
$totalStmt = $pdo->query(
    'SELECT COUNT(*) FROM registrations'
);

$totalRegistrations = (int) $totalStmt->fetchColumn();

$activeStmt = $pdo->query(
    "SELECT COUNT(*) FROM registrations WHERE status = 'Registered'"
);

$activeRegistrations = (int) $activeStmt->fetchColumn();

$cancelledStmt = $pdo->query(
    "SELECT COUNT(*) FROM registrations WHERE status = 'Cancelled'"
);

$cancelledRegistrations = (int) $cancelledStmt->fetchColumn();

// Shared header settings.
$pageTitle = 'Manage Registrations';
$assetPrefix = '../';
$isAdminPage = true;

require __DIR__ . '/../includes/header.php';
?>

<main class="container py-5">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h1 class="mb-1">Manage Registrations</h1>
            <p class="text-muted mb-0">
                View and manage student event registrations.
            </p>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?php echo escape($messageType); ?>">
            <?php echo escape($message); ?>
        </div>
    <?php endif; ?>

    <!-- Summary cards -->
    <div class="row g-3 mb-4">

        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <p class="text-muted mb-1">Total Registrations</p>
                    <h2 class="mb-0">
                        <?php echo $totalRegistrations; ?>
                    </h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <p class="text-muted mb-1">Active Registrations</p>
                    <h2 class="text-success mb-0">
                        <?php echo $activeRegistrations; ?>
                    </h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <p class="text-muted mb-1">Cancelled Registrations</p>
                    <h2 class="text-danger mb-0">
                        <?php echo $cancelledRegistrations; ?>
                    </h2>
                </div>
            </div>
        </div>

    </div>

    <!-- Search and status filter -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">

            <form method="GET" class="row g-3 align-items-end">

                <div class="col-md-6">
                    <label for="search" class="form-label">
                        Search registrations
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="search"
                        name="search"
                        placeholder="Student name, email, or event"
                        value="<?php echo escape($search); ?>"
                    >
                </div>

                <div class="col-md-3">
                    <label for="status" class="form-label">
                        Registration Status
                    </label>

                    <select class="form-select" id="status" name="status">
                        <option value="">All statuses</option>

                        <option
                            value="Registered"
                            <?php echo $statusFilter === 'Registered' ? 'selected' : ''; ?>
                        >
                            Registered
                        </option>

                        <option
                            value="Cancelled"
                            <?php echo $statusFilter === 'Cancelled' ? 'selected' : ''; ?>
                        >
                            Cancelled
                        </option>
                    </select>
                </div>

                <div class="col-md-3 d-flex gap-2">

                    <button type="submit" class="btn btn-primary">
                        Search
                    </button>

                    <a
                        href="registrations.php"
                        class="btn btn-outline-secondary"
                    >
                        Reset
                    </a>

                </div>

            </form>

        </div>
    </div>

    <!-- Registrations table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">Student Registrations</h5>

                <span class="text-muted small">
                    <?php echo count($registrations); ?> result(s)
                </span>
            </div>

            <div class="table-responsive">

                <table class="table table-hover">

                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Student</th>
                            <th>Email</th>
                            <th>Event</th>
                            <th>Event Date</th>
                            <th>Registered At</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (empty($registrations)): ?>

                        <tr>
                            <td colspan="8" class="text-center py-4">
                                No registrations found.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($registrations as $registration): ?>

                            <tr>

                                <td>
                                    <?php echo (int) $registration['registration_id']; ?>
                                </td>

                                <td>
                                    <?php echo escape($registration['full_name']); ?>
                                </td>

                                <td>
                                    <?php echo escape($registration['email']); ?>
                                </td>

                                <td>
                                    <?php echo escape($registration['event_title']); ?>
                                </td>

                                <td>
                                    <?php
                                    echo $registration['event_date']
                                        ? date(
                                            'M d, Y',
                                            strtotime($registration['event_date'])
                                        )
                                        : 'Not set';
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo !empty($registration['registered_at'])
                                        ? escape(
                                            date(
                                                'M d, Y h:i A',
                                                strtotime($registration['registered_at'])
                                            )
                                        )
                                        : 'Not recorded';
                                    ?>
                                </td>

                                <td>

                                    <?php if ($registration['registration_status'] === 'Cancelled'): ?>

                                        <span class="badge bg-danger">
                                            Cancelled
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-success">
                                            <?php echo escape($registration['registration_status']); ?>
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <div class="d-flex flex-wrap gap-2">

                                        <!-- Cancel or Restore -->
                                        <form
                                            method="POST"
                                            onsubmit="return confirm('Are you sure you want to change this registration status?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?php echo escape($_SESSION['csrf_token']); ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="registration_id"
                                                value="<?php echo (int) $registration['registration_id']; ?>"
                                            >

                                            <?php if ($registration['registration_status'] === 'Cancelled'): ?>

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="restore"
                                                >

                                                <button
                                                    type="submit"
                                                    class="btn btn-sm btn-success"
                                                >
                                                    Restore
                                                </button>

                                            <?php else: ?>

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="cancel"
                                                >

                                                <button
                                                    type="submit"
                                                    class="btn btn-sm btn-warning"
                                                >
                                                    Cancel
                                                </button>

                                            <?php endif; ?>

                                        </form>

                                        <!-- Permanently Delete -->
                                        <form
                                            method="POST"
                                            onsubmit="return confirm('WARNING: This will permanently delete this registration record. This action cannot be undone. Continue?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?php echo escape($_SESSION['csrf_token']); ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="registration_id"
                                                value="<?php echo (int) $registration['registration_id']; ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="action"
                                                value="delete"
                                            >

                                            <button
                                                type="submit"
                                                class="btn btn-sm btn-danger"
                                            >
                                                Delete
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>
    </div>

</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
