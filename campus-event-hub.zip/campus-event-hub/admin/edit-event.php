
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';

require_role('admin');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header('Location: dashboard.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM events WHERE id = ?');
$stmt->execute([$id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$event) {
    header('Location: dashboard.php?error=not_found');
    exit;
}

$title = $event['title'];
$description = $event['description'];
$category = $event['category'];
$event_date = $event['event_date'];
$start_time = substr((string) $event['start_time'], 0, 5);
$end_time = substr((string) $event['end_time'], 0, 5);
$venue = $event['venue'];
$capacity = (string) $event['capacity'];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        $errors[] = 'Invalid form submission. Please try again.';
    } else {

        $title = trim((string) ($_POST['title'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        $category = trim((string) ($_POST['category'] ?? ''));
        $event_date = trim((string) ($_POST['event_date'] ?? ''));
        $start_time = trim((string) ($_POST['start_time'] ?? ''));
        $end_time = trim((string) ($_POST['end_time'] ?? ''));
        $venue = trim((string) ($_POST['venue'] ?? ''));
        $capacity = trim((string) ($_POST['capacity'] ?? ''));

        // Validate title.
        if ($title === '' || strlen($title) > 150) {
            $errors[] = 'Enter a title up to 150 characters long.';
        }

        // Validate description.
        if ($description === '') {
            $errors[] = 'Enter a description.';
        }

        // Validate category.
        if ($category === '' || strlen($category) > 100) {
            $errors[] = 'Enter a category up to 100 characters long.';
        }

        // Validate venue.
        if ($venue === '' || strlen($venue) > 255) {
            $errors[] = 'Enter a venue up to 255 characters long.';
        }

        // Validate date.
        $dateObject = DateTimeImmutable::createFromFormat(
            '!Y-m-d',
            $event_date
        );

        if (
            !$dateObject ||
            $dateObject->format('Y-m-d') !== $event_date
        ) {
            $errors[] = 'Enter a valid event date.';
        }

        // Validate times.
        $startObject = DateTimeImmutable::createFromFormat(
            '!H:i',
            $start_time
        );

        $endObject = DateTimeImmutable::createFromFormat(
            '!H:i',
            $end_time
        );

        if (
            !$startObject ||
            $startObject->format('H:i') !== $start_time ||
            !$endObject ||
            $endObject->format('H:i') !== $end_time
        ) {
            $errors[] = 'Enter valid start and end times.';
        } elseif ($end_time <= $start_time) {
            $errors[] = 'End time must be later than start time.';
        }

        // Validate capacity.
        $capacityNumber = filter_var(
            $capacity,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($capacityNumber === false) {
            $errors[] = 'Capacity must be a positive whole number.';
        }

        // Do not allow capacity below active registrations.
        if ($capacityNumber !== false) {

            $countStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM registrations
                 WHERE event_id = ? AND status <> 'Cancelled'"
            );

            $countStmt->execute([$id]);

            $activeRegistrations = (int) $countStmt->fetchColumn();

            if ($capacityNumber < $activeRegistrations) {
                $errors[] = "Capacity cannot be less than the {$activeRegistrations} active registrations.";
            }
        }

        // Update event.
        if (empty($errors)) {
            try {

                $update = $pdo->prepare(
                    'UPDATE events
                     SET title = :title,
                         description = :description,
                         category = :category,
                         event_date = :event_date,
                         start_time = :start_time,
                         end_time = :end_time,
                         venue = :venue,
                         capacity = :capacity
                     WHERE id = :id'
                );

                $update->execute([
                    'title' => $title,
                    'description' => $description,
                    'category' => $category,
                    'event_date' => $event_date,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'venue' => $venue,
                    'capacity' => $capacityNumber,
                    'id' => $id
                ]);

                header('Location: dashboard.php?updated=1');
                exit;

            } catch (PDOException $e) {
                error_log($e->getMessage());
                $errors[] = 'Could not update the event. Please try again.';
            }
        }
    }
}

$categories = [
    'Seminar',
    'Workshop',
    'Sports',
    'Hackathon',
    'Academic',
    'Other'
];

// Shared header settings.
$pageTitle = 'Edit Event';
$assetPrefix = '../';
$isAdminPage = true;

require __DIR__ . '/../includes/header.php';
?>

<main class="container py-5">

    <div class="row justify-content-center">
        <div class="col-lg-8">

            <h1 class="mb-4">Edit Event</h1>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo escape($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">

                    <form method="POST">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?php echo escape($_SESSION['csrf_token']); ?>"
                        >

                        <div class="mb-3">
                            <label for="title" class="form-label">
                                Event Title
                            </label>

                            <input
                                class="form-control"
                                id="title"
                                name="title"
                                maxlength="150"
                                required
                                value="<?php echo escape($title); ?>"
                            >
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">
                                Description
                            </label>

                            <textarea
                                class="form-control"
                                id="description"
                                name="description"
                                rows="4"
                                required
                            ><?php echo escape($description); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="category" class="form-label">
                                Category
                            </label>

                            <select
                                class="form-select"
                                id="category"
                                name="category"
                                required
                            >
                                <option value="">Select a category</option>

                                <?php foreach ($categories as $option): ?>
                                    <option
                                        value="<?php echo escape($option); ?>"
                                        <?php echo $category === $option ? 'selected' : ''; ?>
                                    >
                                        <?php echo escape($option); ?>
                                    </option>
                                <?php endforeach; ?>

                                <?php if (!in_array($category, $categories, true)): ?>
                                    <option
                                        value="<?php echo escape($category); ?>"
                                        selected
                                    >
                                        <?php echo escape($category); ?>
                                    </option>
                                <?php endif; ?>

                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="event_date" class="form-label">
                                Event Date
                            </label>

                            <input
                                type="date"
                                class="form-control"
                                id="event_date"
                                name="event_date"
                                required
                                value="<?php echo escape($event_date); ?>"
                            >
                        </div>

                        <div class="row">

                            <div class="col-md-6 mb-3">
                                <label for="start_time" class="form-label">
                                    Start Time
                                </label>

                                <input
                                    type="time"
                                    class="form-control"
                                    id="start_time"
                                    name="start_time"
                                    required
                                    value="<?php echo escape($start_time); ?>"
                                >
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="end_time" class="form-label">
                                    End Time
                                </label>

                                <input
                                    type="time"
                                    class="form-control"
                                    id="end_time"
                                    name="end_time"
                                    required
                                    value="<?php echo escape($end_time); ?>"
                                >
                            </div>

                        </div>

                        <div class="mb-3">
                            <label for="venue" class="form-label">
                                Venue
                            </label>

                            <input
                                class="form-control"
                                id="venue"
                                name="venue"
                                maxlength="255"
                                required
                                value="<?php echo escape($venue); ?>"
                            >
                        </div>

                        <div class="mb-4">
                            <label for="capacity" class="form-label">
                                Maximum Participants
                            </label>

                            <input
                                type="number"
                                class="form-control"
                                id="capacity"
                                name="capacity"
                                min="1"
                                step="1"
                                required
                                value="<?php echo escape($capacity); ?>"
                            >
                        </div>

                        <button type="submit" class="btn btn-primary">
                            Save Changes
                        </button>

                        <a
                            href="dashboard.php"
                            class="btn btn-outline-secondary"
                        >
                            Cancel
                        </a>

                    </form>

                </div>
            </div>

        </div>
    </div>

</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
