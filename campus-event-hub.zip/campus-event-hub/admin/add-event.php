
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';

// Check admin access before displaying anything.
require_role('admin');

// Create a CSRF token if one does not already exist.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];

$title = '';
$description = '';
$category = '';
$event_date = '';
$start_time = '';
$end_time = '';
$venue = '';
$capacity = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Verify the CSRF token.
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        $errors[] = 'Invalid form submission. Please try again.';
    } else {

        // Get and trim form values.
        $title = trim((string) ($_POST['title'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        $category = trim((string) ($_POST['category'] ?? ''));
        $event_date = trim((string) ($_POST['event_date'] ?? ''));
        $start_time = trim((string) ($_POST['start_time'] ?? ''));
        $end_time = trim((string) ($_POST['end_time'] ?? ''));
        $venue = trim((string) ($_POST['venue'] ?? ''));
        $capacity = trim((string) ($_POST['capacity'] ?? ''));

        // Validate required fields.
        if ($title === '' || strlen($title) > 150) {
            $errors[] = 'Enter an event title (maximum 150 characters).';
        }

        if ($description === '') {
            $errors[] = 'Enter an event description.';
        }

        if ($category === '' || strlen($category) > 100) {
            $errors[] = 'Enter a category (maximum 100 characters).';
        }

        if ($venue === '' || strlen($venue) > 255) {
            $errors[] = 'Enter a venue (maximum 255 characters).';
        }

        // Validate the event date.
        $dateObject = DateTimeImmutable::createFromFormat(
            '!Y-m-d',
            $event_date
        );

        if (
            !$dateObject ||
            $dateObject->format('Y-m-d') !== $event_date
        ) {
            $errors[] = 'Enter a valid event date.';
        } elseif ($event_date < date('Y-m-d')) {
            $errors[] = 'The event date cannot be in the past.';
        }

        // Validate start and end times.
        $startObject = DateTimeImmutable::createFromFormat(
            '!H:i',
            $start_time
        );

        $endObject = DateTimeImmutable::createFromFormat(
            '!H:i',
            $end_time
        );

        if (
            !$startObject ||
            $startObject->format('H:i') !== $start_time ||
            !$endObject ||
            $endObject->format('H:i') !== $end_time
        ) {
            $errors[] = 'Enter valid start and end times.';
        } elseif ($end_time <= $start_time) {
            $errors[] = 'The end time must be later than the start time.';
        }

        // Capacity must be a positive integer.
        $capacityNumber = filter_var(
            $capacity,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        if ($capacityNumber === false) {
            $errors[] = 'Capacity must be a positive whole number.';
        }

        // Save the event if all validation checks pass.
        if (empty($errors)) {
            try {
                $sql = "INSERT INTO events
                    (title, description, category, event_date,
                     start_time, end_time, venue, capacity, status)
                    VALUES
                    (:title, :description, :category, :event_date,
                     :start_time, :end_time, :venue, :capacity, 'open')";

                $stmt = $pdo->prepare($sql);

                $stmt->execute([
                    'title' => $title,
                    'description' => $description,
                    'category' => $category,
                    'event_date' => $event_date,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'venue' => $venue,
                    'capacity' => $capacityNumber
                ]);

                header('Location: dashboard.php?created=1');
                exit;

            } catch (PDOException $e) {
                error_log($e->getMessage());
                $errors[] = 'Unable to save the event. Please check your database structure and try again.';
            }
        }
    }
}

// Shared header settings.
$pageTitle = 'Add New Event';
$assetPrefix = '../';
$isAdminPage = true;

require __DIR__ . '/../includes/header.php';
?>

<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">

            <div class="mb-4">
                <h1 class="fw-bold">Add New Event</h1>
                <p class="text-secondary">
                    Enter the details of the campus event below.
                </p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <strong>Please fix the following:</strong>
                    <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo escape($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">

                    <form method="POST" action="add-event.php">
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?php echo escape($_SESSION['csrf_token']); ?>"
                        >

                        <div class="mb-3">
                            <label for="title" class="form-label">
                                Event Title
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="title"
                                name="title"
                                maxlength="150"
                                value="<?php echo escape($title); ?>"
                                required
                            >
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">
                                Description
                            </label>
                            <textarea
                                class="form-control"
                                id="description"
                                name="description"
                                rows="4"
                                required
                            ><?php echo escape($description); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="category" class="form-label">
                                Category
                            </label>
                            <select
                                class="form-select"
                                id="category"
                                name="category"
                                required
                            >
                                <option value="">Select a category</option>

                                <?php
                                $categories = [
                                    'Seminar',
                                    'Workshop',
                                    'Sports',
                                    'Hackathon',
                                    'Academic',
                                    'Other'
                                ];
                                ?>

                                <?php foreach ($categories as $option): ?>
                                    <option
                                        value="<?php echo escape($option); ?>"
                                        <?php echo $category === $option ? 'selected' : ''; ?>
                                    >
                                        <?php echo escape($option); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="event_date" class="form-label">
                                Event Date
                            </label>
                            <input
                                type="date"
                                class="form-control"
                                id="event_date"
                                name="event_date"
                                min="<?php echo date('Y-m-d'); ?>"
                                value="<?php echo escape($event_date); ?>"
                                required
                            >
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="start_time" class="form-label">
                                    Start Time
                                </label>
                                <input
                                    type="time"
                                    class="form-control"
                                    id="start_time"
                                    name="start_time"
                                    value="<?php echo escape($start_time); ?>"
                                    required
                                >
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="end_time" class="form-label">
                                    End Time
                                </label>
                                <input
                                    type="time"
                                    class="form-control"
                                    id="end_time"
                                    name="end_time"
                                    value="<?php echo escape($end_time); ?>"
                                    required
                                >
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="venue" class="form-label">
                                Venue
                            </label>
                            <input
                                type="text"
                                class="form-control"
                                id="venue"
                                name="venue"
                                maxlength="255"
                                value="<?php echo escape($venue); ?>"
                                required
                            >
                        </div>

                        <div class="mb-4">
                            <label for="capacity" class="form-label">
                                Maximum Participants
                            </label>
                            <input
                                type="number"
                                class="form-control"
                                id="capacity"
                                name="capacity"
                                min="1"
                                step="1"
                                value="<?php echo escape($capacity); ?>"
                                required
                            >
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                Save Event
                            </button>

                            <a
                                href="dashboard.php"
                                class="btn btn-outline-secondary"
                            >
                                Cancel
                            </a>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>
