
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';

require_role('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}

$token = $_POST['csrf_token'] ?? '';

if (
    !is_string($token) ||
    empty($_SESSION['csrf_token']) ||
    !hash_equals($_SESSION['csrf_token'], $token)
) {
    header('Location: dashboard.php?error=csrf');
    exit;
}

$id = filter_var(
    $_POST['event_id'] ?? null,
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

if (!$id) {
    header('Location: dashboard.php?error=invalid_id');
    exit;
}

try {
    // Check whether this event has any registration history.
    $check = $pdo->prepare(
        'SELECT COUNT(*) FROM registrations WHERE event_id = ?'
    );
    $check->execute([$id]);

    if ((int) $check->fetchColumn() > 0) {
        header('Location: dashboard.php?error=has_registrations');
        exit;
    }

    // Delete only when there are no registration records.
    $delete = $pdo->prepare('DELETE FROM events WHERE id = ?');
    $delete->execute([$id]);

    if ($delete->rowCount() === 0) {
        header('Location: dashboard.php?error=not_found');
        exit;
    }

    header('Location: dashboard.php?deleted=1');
    exit;
} catch (PDOException $e) {
    error_log($e->getMessage());
    header('Location: dashboard.php?error=delete_failed');
    exit;
}
