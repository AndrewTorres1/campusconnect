
<?php
require_once __DIR__ . "/includes/auth.php";
require_once __DIR__ . "/config/db.php";

if (!empty($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$pageTitle = "Log In";
$assetPrefix = "";

function escape($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$email = "";
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($_SESSION['csrf_token'], $submittedToken)
    ) {
        $errors[] = "Invalid form submission. Refresh the page and try again.";
    }

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Enter a valid email address.";
    }

    if (!is_string($password) || $password === '' || strlen($password) > 4096) {
        $errors[] = "Enter your password.";
    }

    if (empty($errors)) {
        try {

            $stmt = $pdo->prepare(
                "SELECT id, full_name, email, password_hash, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1"
            );

            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password_hash'])) {

                session_regenerate_id(true);

                $_SESSION['user_id'] = (int) $user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];

                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                if ($_SESSION['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: index.php");
                }

                exit;

            } else {
                $errors[] = "Invalid email or password.";
            }

        } catch (PDOException $e) {

            error_log("Login error: " . $e->getMessage());
            $errors[] = "Login is temporarily unavailable. Please try again.";
        }
    }
}

require __DIR__ . "/includes/header.php";
?>

<style>
:root {
    --dark-green: #14532d;
    --primary-green: #15803d;
    --bright-green: #16a34a;
    --light-green: #dcfce7;
}

/* PAGE BACKGROUND */
body {
    background: #f0fdf4;
}

/* MAIN WRAPPER */
.login-wrapper {
    min-height: 78vh;
    display: flex;
    align-items: center;
    padding-top: 35px;
    padding-bottom: 35px;
}

.login-container {
    max-width: 950px;
    margin: auto;
    width: 100%;
}

/* LOGIN CARD */
.login-card {
    background: #ffffff;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 15px 45px rgba(20, 83, 45, 0.10);
    border: 1px solid #dcfce7;
}

/* LEFT SIDE */
.login-welcome {
    background: linear-gradient(
        145deg,
        #14532d,
        #15803d,
        #16a34a
    );
    color: #ffffff;
    min-height: 550px;
    padding: 45px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

.welcome-content {
    position: relative;
    z-index: 2;
    color: #ffffff;
}

.welcome-icon {
    width: 75px;
    height: 75px;
    background: rgba(255, 255, 255, 0.15);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 35px;
    margin-bottom: 30px;
}

.login-welcome h2 {
    font-size: 32px;
    font-weight: 750;
    line-height: 1.3;
    margin-bottom: 15px;
}

.login-welcome p {
    color: rgba(255, 255, 255, 0.88);
    font-size: 14px;
    line-height: 1.8;
}

.welcome-decoration {
    position: absolute;
    width: 260px;
    height: 260px;
    border: 1px solid rgba(255, 255, 255, 0.13);
    border-radius: 50%;
    right: -100px;
    bottom: -100px;
}

.welcome-decoration::after {
    content: "";
    position: absolute;
    width: 180px;
    height: 180px;
    border: 1px solid rgba(255, 255, 255, 0.13);
    border-radius: 50%;
    right: 40px;
    bottom: 40px;
}

/* RIGHT SIDE */
.login-form-section {
    padding: 50px 45px;
}

.login-heading {
    color: var(--dark-green);
    font-size: 28px;
    font-weight: 750;
    margin-bottom: 8px;
}

.login-description {
    color: #64748b;
    font-size: 14px;
    margin-bottom: 32px;
}

.form-label {
    color: #374151;
    font-weight: 650;
    font-size: 13px;
    margin-bottom: 9px;
}

/* INPUT FIELDS */
.login-input {
    height: 49px;
    border: 1px solid #d1d5db;
    border-radius: 9px;
    padding: 10px 14px;
    font-size: 14px;
    background: #fafffb;
}

.login-input:focus {
    background: #ffffff;
    border-color: var(--bright-green);
    box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.13);
    outline: none;
}

/* PASSWORD */
.password-wrapper {
    position: relative;
}

.password-wrapper input {
    padding-right: 65px;
}

.toggle-password {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: transparent;
    color: var(--primary-green);
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
}

.toggle-password:hover {
    color: var(--dark-green);
}

/* LOGIN BUTTON */
.login-button {
    height: 49px;
    background: var(--primary-green);
    color: #ffffff;
    border: none;
    border-radius: 9px;
    font-size: 14px;
    font-weight: 700;
    transition: 0.2s ease;
}

.login-button:hover {
    background: var(--dark-green);
    color: #ffffff;
    transform: translateY(-1px);
}

/* REGISTRATION LINK */
.register-link {
    color: var(--primary-green);
    font-weight: 650;
    text-decoration: none;
}

.register-link:hover {
    color: var(--dark-green);
    text-decoration: underline;
}

/* FOOTER TEXT */
.login-footer {
    color: #64748b;
    font-size: 12px;
    text-align: center;
    margin-top: 35px;
}

/* ERROR ALERT */
.login-card .alert {
    border-radius: 9px;
    font-size: 13px;
}

/* MOBILE RESPONSIVENESS */
@media (max-width: 767px) {

    .login-wrapper {
        min-height: auto;
    }

    .login-welcome {
        min-height: 230px;
        padding: 30px;
    }

    .welcome-icon {
        width: 55px;
        height: 55px;
        font-size: 27px;
        margin-bottom: 18px;
    }

    .login-welcome h2 {
        font-size: 24px;
    }

    .login-form-section {
        padding: 35px 25px;
    }

    .login-heading {
        font-size: 25px;
    }
}
</style>

<main class="container login-wrapper">

    <div class="login-container">

        <div class="login-card">

            <div class="row g-0">

                <!-- WELCOME SECTION -->
                <div class="col-md-5">

                    <div class="login-welcome">

                        <div class="welcome-content">

                            <div class="welcome-icon">
                                <i class="bi bi-mortarboard-fill"></i>
                            </div>

                            <h2>
                                Mini Campus
                                <br>
                                Event HUB
                            </h2>

                            <p>
                                Stay connected with your campus.
                                Discover upcoming events, and never miss an
                                important activity.
                            </p>

                            <div class="mt-4 small fw-semibold">
                                YOUR CAMPUS. YOUR EVENTS.
                            </div>

                        </div>

                        <div class="welcome-decoration"></div>

                    </div>

                </div>

                <!-- LOGIN FORM -->
                <div class="col-md-7">

                    <div class="login-form-section">

                        <h1 class="login-heading">
                            Welcome Back!
                        </h1>

                        <p class="login-description">
                            Enter your account details to continue.
                        </p>

                        <!-- ERROR MESSAGES -->
                        <?php if (!empty($errors)): ?>

                            <div class="alert alert-danger rounded-3 small">

                                <ul class="mb-0 ps-3">

                                    <?php foreach ($errors as $error): ?>

                                        <li>
                                            <?= escape($error); ?>
                                        </li>

                                    <?php endforeach; ?>

                                </ul>

                            </div>

                        <?php endif; ?>

                        <!-- LOGIN FORM -->
                        <form method="POST" action="login.php">

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= escape($_SESSION['csrf_token']); ?>"
                            >

                            <!-- EMAIL -->
                            <div class="mb-4">

                                <label for="email" class="form-label">
                                    Email Address
                                </label>

                                <input
                                    type="email"
                                    class="form-control login-input"
                                    id="email"
                                    name="email"
                                    placeholder="Enter your email address"
                                    autocomplete="email"
                                    maxlength="150"
                                    value="<?= escape($email); ?>"
                                    required
                                >

                            </div>

                            <!-- PASSWORD -->
                            <div class="mb-4">

                                <label for="password" class="form-label">
                                    Password
                                </label>

                                <div class="password-wrapper">

                                    <input
                                        type="password"
                                        class="form-control login-input"
                                        id="password"
                                        name="password"
                                        placeholder="Enter your password"
                                        autocomplete="current-password"
                                        maxlength="4096"
                                        required
                                    >

                                    <button
                                        type="button"
                                        class="toggle-password"
                                        id="togglePassword"
                                        aria-label="Show password"
                                        aria-pressed="false"
                                    >
                                        SHOW
                                    </button>

                                </div>

                            </div>

                            <!-- SUBMIT BUTTON -->
                            <button
                                type="submit"
                                class="btn login-button w-100"
                            >
                                Log In to Your Account
                                <i class="bi bi-arrow-right ms-2"></i>
                            </button>

                        </form>

                        <!-- REGISTER LINK -->
                        <div class="text-center mt-4">

                            <p class="text-secondary small mb-0">
                                Don't have an account?

                                <a
                                    href="register.php"
                                    class="register-link"
                                >
                                    Create one
                                </a>
                            </p>

                        </div>

                        <div class="login-footer">
                            Campus Events Management System
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</main>

<script>
const passwordInput = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');

togglePassword.addEventListener('click', function () {

    const isPassword = passwordInput.type === 'password';

    passwordInput.type = isPassword ? 'text' : 'password';

    this.textContent = isPassword ? 'HIDE' : 'SHOW';

    this.setAttribute(
        'aria-label',
        isPassword ? 'Hide password' : 'Show password'
    );

    this.setAttribute('aria-pressed', String(isPassword));

});
</script>

<?php require __DIR__ . "/includes/footer.php"; ?>
